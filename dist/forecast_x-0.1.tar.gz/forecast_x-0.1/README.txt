# Forecast_x
python toolkit for Naive models for time series


## Installation

## Documentation
Documentation will be available soon!.

## Support


## Code of Conduct
Everyone interacting with this project's codebases, issue trackers, and mailing lists is expected to follow the Code of Conduct.
